ROOT SCORE Ver1.1
・4人麻雀は25,000点スタート
・1週間予定表を追加
・このフォルダの index.html と poster.png をGitHubへ上書きしてください
