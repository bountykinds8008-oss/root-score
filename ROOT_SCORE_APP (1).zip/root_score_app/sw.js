
const CACHE="root-score-v1";
const ASSETS=["./","index.html","style.css","app.js","manifest.webmanifest","poster.png"];
self.addEventListener("install",e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS.filter(Boolean)))));
self.addEventListener("fetch",e=>e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request))));
